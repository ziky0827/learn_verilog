clear all;close all;clc;
%=======================================================
% generating 1/4 cos wave data with txt hex format
%=======================================================

N   = 64 ;
n   = 0:N ;
w   = n/N *pi/2 ;
st  = (2^10 /2 -1)*cos(w) ;
st  = floor(st) ;
%% first quadrant
st1  = st+512 ;
figure(5) ;
plot(n, st1) ;
hold on ;
%% 2nd quadrant
n2 = 64 + n ;
st2 = 512 - st(64-n+1);
plot(n2, st2)
hold on

%% 3rd quadrant
n3 = 128 + n ;
st3 = 512 - st ;
plot(n3, st3) ;
hold on ;

%% 4th quadrant
n4 = 192 + n ;
st4 = 512 + st(64-n+1) ;
plot(n4, st4) ;
hold on ;
